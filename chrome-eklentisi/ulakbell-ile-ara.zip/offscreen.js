// Yalnız kısayola basıldığında açılır: panodaki metni okuyup arka plana verir, sonra kapatılır.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen' || msg.type !== 'readClipboard') return;
  const t = document.getElementById('t');
  t.value = '';
  t.focus();
  document.execCommand('paste');
  sendResponse(t.value.slice(0, 1000));
});
