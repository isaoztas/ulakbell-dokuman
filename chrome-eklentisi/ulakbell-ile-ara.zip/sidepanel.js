// Yan panel telefonu.
// ulakBELL görünmeyen bir çerçevede çalışır (teleweb, ses ve santral bağlantısı orada); bu sayfa onun
// sade bir uzaktan kumandasıdır. Giriş, "Burada Kullan" ve aktarma gibi işlerde çerçeve görünür olur.
const DEFAULTS = { host: 'emsal.ulakbel.com' };
const $ = (id) => document.getElementById(id);
const frame = $('frame');
let host = DEFAULTS.host, origin = '';

async function start() {
  ({ host } = await chrome.storage.sync.get(DEFAULTS));
  origin = 'https://' + host;
  $('sub').textContent = host;
  await chrome.runtime.sendMessage({ type: 'ensurePanelRule' }).catch(() => {});
  frame.src = origin + '/home';
  checkMic();
}

// Yan panel izin penceresi gösteremez; mikrofon iznini eklentiye bir kez sekmede veririz.
async function checkMic() {
  try {
    const st = await navigator.permissions.query({ name: 'microphone' });
    const upd = () => $('micBar').classList.toggle('on', st.state !== 'granted');
    upd(); st.onchange = () => { upd(); if (st.state === 'granted') frame.src = frame.src; };
  } catch (_) {}
}
$('micBtn').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('izin.html') });
$('reload').onclick = () => { frame.src = origin + '/home'; };
$('openTab').onclick = () => chrome.tabs.create({ url: origin + '/home' });
$('classicBtn').onclick = () => setClassic(!document.body.classList.contains('classic'));
function setClassic(on) {
  document.body.classList.toggle('classic', on);
  $('classicBtn').classList.toggle('on', on);
  $('classicBtn').title = on ? 'Sade görünüme dön' : 'Klasik görünüm (aktarma, konferans ve diğer işlemler)';
}

// ---- Çerçeveyle konuşma ----
let seq = 0;
const waiting = new Map();
function ask(action, number) {
  return new Promise((resolve) => {
    if (!frame.contentWindow || !origin) return resolve(null);
    const id = 'ub' + (++seq);
    const t = setTimeout(() => { waiting.delete(id); resolve(null); }, 6000);
    waiting.set(id, (r) => { clearTimeout(t); resolve(r); });
    frame.contentWindow.postMessage({ ubPanel: 'req', id, action, number }, origin);
  });
}
window.addEventListener('message', (e) => {
  if (e.source !== frame.contentWindow || e.origin !== origin || !e.data) return;
  const d = e.data;
  if (d.ubPanel === 'res' && waiting.has(d.id)) { waiting.get(d.id)(d.result); waiting.delete(d.id); }
  if (d.ubPanel === 'notify') {
    chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title: String(d.title || 'ulakBELL').slice(0, 120), message: String(d.body || '').slice(0, 300), priority: 2 }).catch(() => {});
  }
});

// Arka plandan (sitelerde numaraya tıklama, kısayollar) gelen istekler
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.target !== 'sidepanel') return;
  if (msg.action === 'ping') { sendResponse({ ok: true, host }); return; }
  ask(msg.action, msg.number).then((r) => { sendResponse(r || { ok: false, reason: 'no_teleweb' }); poll(); });
  return true;
});
chrome.storage.onChanged.addListener((ch) => { if (ch.host) start(); });

// 05321234567 → 0532 123 45 67 (yalnız görünüm)
function fmtNum(n) {
  const d = String(n || '').replace(/\D/g, '');
  let m = d.match(/^0?([2-58]\d{2})(\d{3})(\d{2})(\d{2})$/);
  if (m && (d.length === 10 || d.length === 11)) return `0${m[1]} ${m[2]} ${m[3]} ${m[4]}`;
  m = d.match(/^444(\d{2})(\d{2})$/);
  if (m) return `444 ${m[1]} ${m[2]}`;
  return String(n || '');
}

// ---- Arayüz ----
const KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'];
function buildPad(el, onKey) {
  for (const k of KEYS) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'k'; b.textContent = k;
    b.onclick = () => onKey(k);
    el.appendChild(b);
  }
}
buildPad($('pad'), (k) => { $('num').value += k; $('num').focus(); });
buildPad($('dpad'), (k) => ask('dtmf', k));
$('padToggle').onclick = () => {
  const show = $('pad').hidden;
  $('pad').hidden = !show;
  $('padToggle').textContent = show ? '⌨ Tuş takımını gizle' : '⌨ Tuş takımını göster';
};

const REASONS = {
  no_teleweb: 'Telefon hazır değil.', not_registered: 'Telefon santrale bağlı değil.',
  busy: 'Şu an başka bir görüşme var.', not_started: 'Arama başlatılamadı.', error: 'Arama başlatılamadı.'
};
async function dial(number) {
  number = String(number || '').replace(/[^\d*#+]/g, '');
  $('err').textContent = '';
  if (number.replace(/\D/g, '').length < 3) { $('err').textContent = 'Numara yazın.'; return; }
  const r = await ask('call', number);
  if (!r || !r.ok) $('err').textContent = REASONS[(r && r.reason) || 'error'] || REASONS.error;
  else $('num').value = '';
  poll();
}
$('dialForm').onsubmit = (e) => { e.preventDefault(); dial($('num').value); };
$('status').onchange = async () => {
  const r = await ask('setStatus', $('status').value);
  if (!r || !r.ok) $('err').textContent = r && r.reason === 'locked' ? 'Durum şu an değiştirilemiyor (görüşme sırasında ya da işlem sürerken).' : 'Durum değiştirilemedi.';
  else $('err').textContent = '';
  optSig = ''; poll();
};
$('bHang').onclick = () => ask('hangup').then(poll);
$('bAns').onclick = () => ask('answer').then(poll);
$('bMute').onclick = () => ask('mute').then(poll);
$('bHold').onclick = () => ask('hold').then(poll);
$('bKeys').onclick = () => { $('dpad').classList.toggle('on'); $('bKeys').classList.toggle('on'); };
$('bMore').onclick = () => setClassic(true);

let optSig = '';
function renderStatus(st) {
  const sel = $('status');
  const opts = st.options && st.options.length ? st.options : [{ value: st.queue || '', label: st.ext ? 'Dahili ' + st.ext : 'Durum', disabled: false }];
  const sig = JSON.stringify(opts);
  if (sig !== optSig) {
    optSig = sig;
    sel.textContent = '';
    for (const o of opts) {
      const op = document.createElement('option');
      op.value = o.value; op.textContent = o.label; op.disabled = !!o.disabled;
      sel.appendChild(op);
    }
  }
  if (document.activeElement !== sel) sel.value = String(st.queue);
  sel.disabled = !st.canChange || !(st.options && st.options.length);
  sel.title = sel.disabled ? 'Durum şu an değiştirilemiyor' : 'Durumunuz (müsait, meşgul, mola)';
  $('statusWrap').classList.toggle('away', String(st.queue) !== 'online');
  const w = $('waiting');
  if (st.waiting === null || st.waiting === undefined) w.hidden = true;
  else { w.hidden = false; w.textContent = st.waiting + ' kuyrukta'; w.classList.toggle('zero', !st.waiting); }
  $('sub').textContent = [st.ext ? 'Dahili ' + st.ext : '', host, String(st.queue) !== 'online' && st.breakTime ? '⏱ ' + st.breakTime : ''].filter(Boolean).join(' · ');
}

function renderCall(st) {
  const active = !!st.active;
  $('idle').hidden = active;
  $('call').hidden = !active;
  if (!active) { $('dpad').classList.remove('on'); $('bKeys').classList.remove('on'); return; }
  const incoming = st.phase === 'ararken';
  const live = st.phase === 'acinca';
  $('cKind').textContent = incoming ? 'Gelen çağrı' : (cur && cur.dir === 'in' ? 'Gelen çağrı' : 'Giden çağrı');
  $('cNum').textContent = fmtNum(st.number) || '—';
  $('cWho').textContent = st.name || '';
  $('cSt').textContent = live ? (st.held ? 'Beklemede' : 'Görüşmede') + (st.duration ? ' · ' + st.duration : '') : st.state;
  $('call').classList.toggle('ring', !live);
  $('call').classList.toggle('held', live && !!st.held);
  $('cActs').hidden = !live;
  $('bAns').hidden = !incoming;
  $('bHang').textContent = incoming ? '✕ Reddet' : '⏻ Kapat';
  $('bMute').classList.toggle('on', !!st.muted);
  $('bMute').querySelector('em').textContent = st.muted ? 'Sesi aç' : 'Sustur';
  $('bHold').classList.toggle('on', !!st.held);
  $('bHold').querySelector('em').textContent = st.held ? 'Devam' : 'Beklet';
  if (!live) $('dpad').classList.remove('on');
}

// ---- Son aramalar (yalnız bu bilgisayarda, eklentinin yerel deposunda) ----
let cur = null, history = [];
chrome.storage.local.get({ history: [] }).then((r) => { history = r.history || []; renderHistory(); });
function trackHistory(st) {
  const now = Date.now();
  if (st.active) {
    if (!cur) cur = { number: st.number || '', name: st.name || '', dir: st.phase === 'ararken' ? 'in' : 'out', at: now, connectedAt: null };
    if (st.number) cur.number = st.number;
    if (st.name) cur.name = st.name;
    if (st.phase === 'acinca' && !cur.connectedAt) cur.connectedAt = now;
  } else if (cur) {
    const c = cur; cur = null;
    if (!c.number) return;
    history.unshift({ number: c.number, name: c.name, dir: c.dir, at: c.at, dur: c.connectedAt ? Math.round((now - c.connectedAt) / 1000) : 0, missed: c.dir === 'in' && !c.connectedAt });
    history = history.slice(0, 15);
    chrome.storage.local.set({ history });
    renderHistory();
  }
}
function fmtTime(ts) {
  const d = new Date(ts), today = new Date();
  const hm = d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  return d.toDateString() === today.toDateString() ? hm : d.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' }) + ' ' + hm;
}
function fmtDur(s) { return s ? (s >= 60 ? Math.floor(s / 60) + ' dk ' : '') + (s % 60) + ' sn' : ''; }
function renderHistory() {
  const box = $('hist');
  box.textContent = '';
  if (!history.length) { box.innerHTML = '<div class="empty">Henüz arama yok.</div>'; return; }
  for (const h of history) {
    const it = document.createElement('div'); it.className = 'it';
    const ic = document.createElement('span'); ic.className = 'ic' + (h.missed ? ' miss' : h.dir === 'in' ? ' in' : '');
    ic.textContent = h.missed ? '✕' : h.dir === 'in' ? '↙' : '↗';
    ic.title = h.missed ? 'Cevapsız' : h.dir === 'in' ? 'Gelen' : 'Giden';
    const n = document.createElement('div'); n.className = 'n'; n.textContent = fmtNum(h.number);
    if (h.name) { const sm = document.createElement('small'); sm.textContent = h.name; n.appendChild(sm); }
    const t = document.createElement('div'); t.className = 't'; t.textContent = fmtTime(h.at) + (h.dur ? '\n' + fmtDur(h.dur) : h.missed ? '\ncevapsız' : '');
    t.style.whiteSpace = 'pre';
    const c = document.createElement('button'); c.className = 'c'; c.type = 'button'; c.textContent = '📞'; c.title = h.number + ' ara';
    c.onclick = () => dial(h.number);
    it.append(ic, n, t, c);
    box.appendChild(it);
  }
}

// ---- Durum takibi ----
let polling = false;
async function poll() {
  if (polling) return;
  polling = true;
  try {
    const st = await ask('status');
    const ready = !!(st && st.present && st.ready);
    const attention = !!(st && st.attention);
    document.body.classList.toggle('wait', !ready || attention);
    $('waitNote').textContent = attention
      ? 'ulakBELL bir işlem bekliyor (onay, mola isteği ya da sonuç kodu). Aşağıdan tamamlayın; sonra panel sade görünüme döner.'
      : 'Telefon hazırlanıyor. Giriş ekranı çıkarsa giriş yapın; "Burada Kullan" uyarısı çıkarsa basın.';
    if (st && st.present) {
      renderStatus(st);
      trackHistory(st);
      renderCall(st);
    } else {
      $('sub').textContent = host;
    }
  } finally {
    polling = false;
  }
}
setInterval(poll, 700);
start();
