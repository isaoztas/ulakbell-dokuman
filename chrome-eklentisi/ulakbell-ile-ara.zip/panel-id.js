// ulakBELL ile Ara — yan panel kimliği (ayrık dünyada çalışır, eklenti kimliğini bilir).
// Yan panel köprüsü (panel-main.js) yalnız bu kimliğe sahip eklentinin sayfasından gelen komutları kabul eder;
// böylece ulakBELL'i kendi sayfasına gömen başka bir eklenti sizin hattınızdan arama yaptıramaz.
if (window.top !== window) {
  const ORIGIN = 'chrome-extension://' + chrome.runtime.id;
  const mark = () => {
    const el = document.documentElement;
    if (el && el.getAttribute('data-ub-ext') !== ORIGIN) el.setAttribute('data-ub-ext', ORIGIN);
  };
  mark();
  document.addEventListener('DOMContentLoaded', mark);
  document.addEventListener('ub-ext-q', mark);   // köprü sorarsa yeniden yaz
  setInterval(mark, 1000);
}
