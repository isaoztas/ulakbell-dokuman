// ulakBELL ile Ara — yan panel kimliği (ayrık dünyada çalışır, eklenti kimliğini bilir).
// Yan panel köprüsü (panel-main.js) yalnız bu kimliğe sahip eklentinin sayfasından gelen komutları kabul eder;
// böylece ulakBELL'i kendi sayfasına gömen başka bir eklenti sizin hattınızdan arama yaptıramaz.
if (window.top !== window) {
  document.documentElement.setAttribute('data-ub-ext', new URL(chrome.runtime.getURL('/')).origin);
}
