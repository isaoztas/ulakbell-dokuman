const s = document.getElementById('s');
navigator.mediaDevices.getUserMedia({ audio: true }).then((st) => {
  st.getTracks().forEach((t) => t.stop());
  s.className = 'ok'; s.textContent = 'İzin verildi. Bu sekmeyi kapatabilir, yan paneldeki telefonu kullanabilirsiniz.';
  setTimeout(() => window.close(), 2500);
}).catch((e) => {
  s.className = 'err';
  s.textContent = 'İzin verilmedi (' + e.name + '). Adres çubuğundaki simgeden mikrofona izin verip sayfayı yenileyin.';
});
