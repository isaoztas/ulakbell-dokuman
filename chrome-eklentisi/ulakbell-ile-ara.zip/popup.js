const DEFAULTS = { host: 'emsal.ulakbel.com', focusTab: false, highlight: true };
const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(DEFAULTS).then((s) => {
  $('host').value = s.host;
  $('highlight').checked = s.highlight;
  $('focusTab').checked = s.focusTab;
});

$('host').addEventListener('change', () => {
  let h = $('host').value.trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  if (!/(^|\.)(ulakbel\.com|emsal\.im)$/i.test(h)) {
    show({ ok: false, text: 'Adres *.ulakbel.com ya da *.emsal.im olmalı.' });
    return;
  }
  $('host').value = h;
  chrome.storage.sync.set({ host: h });
  show({ ok: true, text: 'Kaydedildi.' });
});
$('highlight').addEventListener('change', (e) => chrome.storage.sync.set({ highlight: e.target.checked }));
$('focusTab').addEventListener('change', (e) => chrome.storage.sync.set({ focusTab: e.target.checked }));

function show(res) {
  $('msg').textContent = res.text || '';
  $('msg').className = res.ok ? 'ok' : 'err';
}

$('f').addEventListener('submit', async (e) => {
  e.preventDefault();
  const number = $('num').value.trim();
  if (!number) return;
  show({ ok: true, text: 'Gönderiliyor…' });
  show(await chrome.runtime.sendMessage({ type: 'call', number }));
  refresh();
});

// Süren görüşme ve Kapat
async function refresh() {
  const st = await chrome.runtime.sendMessage({ type: 'status' });
  const box = $('call');
  if (st && st.active) {
    box.hidden = false; box.style.display = 'flex';
    $('callTxt').textContent = `${st.number} · ${st.state}${st.duration ? ' · ' + st.duration : ''}`;
  } else {
    box.hidden = true; box.style.display = 'none';
  }
}
$('hang').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'hangup' });
  refresh();
});
refresh();
setInterval(refresh, 1000);
