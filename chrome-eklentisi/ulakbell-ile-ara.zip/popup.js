const DEFAULTS = { host: 'emsal.ulakbel.com', focusTab: false, highlight: true };
const $ = (id) => document.getElementById(id);

chrome.storage.sync.get(DEFAULTS).then((s) => {
  $('host').value = s.host;
  $('highlight').checked = s.highlight;
  $('focusTab').checked = s.focusTab;
});

$('host').addEventListener('change', () => {
  let h = $('host').value.trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  if (!/(^|\.)(ulakbel\.com|emsal\.im)$/i.test(h)) {
    show({ ok: false, text: 'Adres *.ulakbel.com ya da *.emsal.im olmalı.' });
    return;
  }
  $('host').value = h;
  chrome.storage.sync.set({ host: h });
  show({ ok: true, text: 'Kaydedildi.' });
});
$('highlight').addEventListener('change', (e) => chrome.storage.sync.set({ highlight: e.target.checked }));
$('focusTab').addEventListener('change', (e) => chrome.storage.sync.set({ focusTab: e.target.checked }));

function show(res) {
  $('msg').textContent = res.text || '';
  $('msg').className = res.ok ? 'ok' : 'err';
}

$('f').addEventListener('submit', async (e) => {
  e.preventDefault();
  const number = $('num').value.trim();
  if (!number) return;
  show({ ok: true, text: 'Gönderiliyor…' });
  show(await chrome.runtime.sendMessage({ type: 'call', number }));
  refresh();
});

// Süren görüşme ve Kapat
async function refresh() {
  const st = await chrome.runtime.sendMessage({ type: 'status' });
  const box = $('call');
  if (st && st.active) {
    box.hidden = false; box.style.display = 'flex';
    $('callTxt').textContent = `${st.number} · ${st.state}${st.duration ? ' · ' + st.duration : ''}`;
  } else {
    box.hidden = true; box.style.display = 'none';
  }
}
$('hang').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'hangup' });
  refresh();
});
refresh();
setInterval(refresh, 1000);

// Kısayollar (her programda çalışır)
chrome.commands.getAll().then((cmds) => {
  const k = Object.fromEntries(cmds.map(c => [c.name, c.shortcut]));
  const box = $('kisayol');
  box.textContent = '';
  const b = document.createElement('b'); b.textContent = 'Her programdan arama: '; box.appendChild(b);
  box.appendChild(document.createTextNode(k.ara
    ? `numarayı kopyalayın (ya da seçin), ${k.ara} tuşlarına basın. Kapatmak: ${k.kapat || '—'}. `
    : 'kısayol atanmamış. '));
  const a = document.createElement('a'); a.href = '#'; a.textContent = 'Kısayolları değiştir';
  a.onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url: 'chrome://extensions/shortcuts' }); };
  box.appendChild(a);
});

// Yan panel: telefonu Chrome'un sağında sürekli açık tut
let winId = null;
chrome.windows.getCurrent().then((w) => { winId = w.id; });
$('panel').addEventListener('click', async () => {
  try {
    await chrome.sidePanel.open({ windowId: winId });
    window.close();
  } catch (e) {
    show({ ok: false, text: 'Yan panel açılamadı: ' + (e.message || e) });
  }
});
