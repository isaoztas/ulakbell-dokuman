// ulakBELL ile Ara — sayfa betiği
// Sayfadaki telefon numaralarını sayfanın DOM'una dokunmadan (CSS Highlight API) işaretler,
// tıklanınca numarayı arka plana gönderir; tel: bağlantılarını da ulakBELL'e yönlendirir.
(() => {
  if (window.__ulakbellAra) return;
  window.__ulakbellAra = true;

  // +90 532 123 45 67 · 0 (532) 123 45 67 · 0532-123-4567 · 0212 123 45 67 · 0850 ... · 444 1 234 · 444 12 34
  const RE = /(?<![\d+])(?:(?:\+|00)\s?90[\s.\-]?|90[\s.\-]|0[\s.\-]?)?(?:\([2-58]\d{2}\)|\(0[2-58]\d{2}\)|[2-58]\d{2})[\s.\-]?\d{3}[\s.\-]?\d{2}[\s.\-]?\d{2}(?![\d])|(?<![\d])444[\s.\-]?(?:\d[\s.\-]?\d{3}|\d{2}[\s.\-]?\d{2})(?![\d])/g;
  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'SVG', 'CANVAS', 'IFRAME', 'TEMPLATE']);
  const MAX_MATCHES = 3000;

  const IS_ULAKBELL = /(^|\.)(ulakbel\.com|emsal\.im)$/i.test(location.hostname);
  const IS_TOP = window === window.top;
  const IS_SHEETS = IS_TOP && location.hostname === 'docs.google.com' && location.pathname.startsWith('/spreadsheets/');
  // ulakBELL'in kendi sayfalarında numaraya tıklamak kaydı açmak gibi başka işler yapar;
  // orada tıklamayı ele geçirmeyiz, numaranın üstünde çıkan "Ara" düğmesiyle ararız.
  // ulakBELL'de yalnız tıklanabilir öğelerdeki (bağlantı, düğme, satır vb.) numaralarda düğme modu.
  let BUTTON_MODE = false;
  function isClickable(el) {
    if (!el || el.nodeType !== 1) return false;
    if (el.closest('a[href],button,input,select,textarea,label,summary,[role=button],[role=link],[role=tab],[role=menuitem],[onclick],[contenteditable=true]')) return true;
    return getComputedStyle(el).cursor === 'pointer';
  }

  let enabled = true;
  let byNode = new Map();   // Text -> [{start, end, number}]
  const hasHighlight = typeof CSS !== 'undefined' && CSS.highlights && typeof Highlight === 'function';
  const hl = hasHighlight ? new Highlight() : null;
  const hlHover = hasHighlight ? new Highlight() : null;

  function validNumber(m, allowBare = false) {
    const d = m.replace(/\D/g, '');
    if (/^444\d{4}$/.test(d)) return d;
    let n = d;
    if (n.startsWith('0090')) n = n.slice(4);
    else if (n.startsWith('90') && n.length === 12) n = n.slice(2);
    else if (n.startsWith('0')) n = n.slice(1);
    if (!/^([2-5]\d{9}|8(00|50)\d{7})$/.test(n)) return null;
    // Ayraçsız ve ön eksiz 10 haneli sayılar (sipariş no vb.) numara sayılmasın
    if (!allowBare && /^\d{10}$/.test(m)) return null;
    return '0' + n;
  }

  function injectStyle() {
    if (document.getElementById('ulakbell-ara-style')) return;
    const st = document.createElement('style');
    st.id = 'ulakbell-ara-style';
    st.textContent = `
      ::highlight(ulakbell-tel){ text-decoration: underline dotted #16a34a 2px; text-underline-offset: 3px; }
      ::highlight(ulakbell-tel-hover){ background-color: rgba(22,163,74,.18); text-decoration: underline solid #16a34a 2px; text-underline-offset: 3px; }`;
    (document.head || document.documentElement).appendChild(st);
  }

  function scan() {
    byNode = new Map();
    if (hl) hl.clear();
    if (!enabled || !document.body) return;
    let count = 0;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const v = node.nodeValue;
        if (!v || v.length < 7 || !/\d{3}/.test(v)) return NodeFilter.FILTER_REJECT;
        for (let el = node.parentElement; el && el !== document.body; el = el.parentElement) {
          if (SKIP.has(el.tagName.toUpperCase()) || el.isContentEditable || el.id === 'ulakbell-ara-ui') return NodeFilter.FILTER_REJECT;
          if (IS_ULAKBELL && el.classList && el.classList.contains('HuxTeleweb')) return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let node;
    while ((node = walker.nextNode()) && count < MAX_MATCHES) {
      const text = node.nodeValue;
      RE.lastIndex = 0;
      let m;
      while ((m = RE.exec(text))) {
        const number = validNumber(m[0]);
        if (!number) continue;
        const item = { start: m.index, end: m.index + m[0].length, number };
        if (!byNode.has(node)) byNode.set(node, []);
        byNode.get(node).push(item);
        if (hl) {
          const r = document.createRange();
          r.setStart(node, item.start); r.setEnd(node, item.end);
          hl.add(r);
        }
        count++;
      }
    }
  }

  // Sayfa sürekli değişiyorsa (saat, sayaç, canlı listeler) tarama hiç ertelenip kalmasın:
  // son değişiklikten 400 ms sonra, ama en geç 1,5 sn içinde tara.
  let scanTimer = null, firstPending = 0;
  function scheduleScan() {
    const now = Date.now();
    if (!firstPending) firstPending = now;
    clearTimeout(scanTimer);
    const wait = Math.max(0, Math.min(400, 1500 - (now - firstPending)));
    scanTimer = setTimeout(() => { firstPending = 0; scan(); }, wait);
  }

  // Tıklama tuzağına karşı: görünmez, şeffaf ya da çok küçük yazılmış numaralar aranmaz
  function looksVisible(el) {
    if (!el) return false;
    try {
      if (el.checkVisibility && !el.checkVisibility({ opacityProperty: true, visibilityProperty: true, contentVisibilityAuto: true })) return false;
      const cs = getComputedStyle(el);
      if (parseFloat(cs.fontSize) < 7) return false;
      const alpha = (c) => { const m = /rgba?\(([^)]+)\)/.exec(c); if (!m) return 1; const p = m[1].split(/[,\s/]+/).filter(Boolean); return p.length > 3 ? parseFloat(p[3]) : 1; };
      if (alpha(cs.color) < 0.15 && alpha(cs.webkitTextFillColor || cs.color) < 0.15) return false;
      for (let e = el, i = 0; e && i < 30; e = e.parentElement, i++) {
        if (parseFloat(getComputedStyle(e).opacity) < 0.15) return false;
      }
    } catch (_) {}
    return true;
  }

  // İmlecin altındaki numarayı bul
  function hitTest(x, y) {
    const pos = document.caretPositionFromPoint
      ? document.caretPositionFromPoint(x, y)
      : (document.caretRangeFromPoint && document.caretRangeFromPoint(x, y));
    if (!pos) return null;
    const node = pos.offsetNode || pos.startContainer;
    const offset = pos.offset != null ? pos.offset : pos.startOffset;
    const items = byNode.get(node);
    if (!items) return null;
    if (!looksVisible(node.parentElement)) return null;
    for (const it of items) {
      if (offset < it.start || offset > it.end) continue;
      const r = document.createRange();
      r.setStart(node, it.start); r.setEnd(node, it.end);
      for (const rect of r.getClientRects()) {
        if (x >= rect.left - 2 && x <= rect.right + 2 && y >= rect.top - 2 && y <= rect.bottom + 2) {
          return { node, item: it, range: r, rect };
        }
      }
    }
    return null;
  }

  // Küçük arayüz (ipucu + bildirim), sayfa stillerinden etkilenmesin diye shadow DOM içinde
  let ui, tip, toastBox, sheetBtn, sheetNumber = null;
  let tipHovered = false, tipNumber = null, hideTimer = null;
  function ensureUi() {
    if (ui && ui.isConnected) return;
    ui = document.createElement('div');
    ui.id = 'ulakbell-ara-ui';
    ui.style.cssText = 'all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483647';
    const sh = ui.attachShadow({ mode: 'closed' });
    sh.innerHTML = `
      <style>
        .tip{position:fixed;display:none;transform:translate(-50%,-100%);margin-top:-6px;background:#16a34a;color:#fff;
             font:600 12px/1 system-ui,-apple-system,"Segoe UI",sans-serif;padding:6px 9px;border-radius:999px;white-space:nowrap;
             box-shadow:0 2px 8px rgba(0,0,0,.25)}
        .sheetbtn{position:fixed;display:none;pointer-events:auto;cursor:pointer;background:#16a34a;color:#fff;border:0;
             font:600 12px/1 system-ui,-apple-system,"Segoe UI",sans-serif;padding:7px 10px;border-radius:999px;white-space:nowrap;
             box-shadow:0 2px 8px rgba(0,0,0,.3)}
        .sheetbtn:hover{background:#15803d}
        .toasts{position:fixed;right:16px;bottom:16px;display:flex;flex-direction:column;gap:8px;align-items:flex-end}
        .toast{pointer-events:auto;background:#1f2937;color:#fff;font:14px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;
               padding:10px 14px;border-radius:10px;box-shadow:0 4px 16px rgba(0,0,0,.3);max-width:340px;display:flex;gap:10px;align-items:center}
        .toast.ok{background:#15803d}
        .toast.err{background:#b91c1c}
        .toast button{all:unset;cursor:pointer;background:rgba(255,255,255,.2);padding:4px 10px;border-radius:6px;font-weight:600;white-space:nowrap}
        .callp{pointer-events:auto;background:#111827;color:#fff;font:14px/1.3 system-ui,-apple-system,"Segoe UI",sans-serif;
               padding:12px 12px 12px 16px;border-radius:14px;box-shadow:0 6px 24px rgba(0,0,0,.35);display:flex;gap:14px;align-items:center;min-width:250px}
        .callp .info{flex:1;display:flex;flex-direction:column;gap:2px}
        .callp .num{font-weight:700;font-size:15px;letter-spacing:.3px}
        .callp .st{font-size:12px;color:#9ca3af;display:flex;gap:6px;align-items:center}
        .callp .dot{width:8px;height:8px;border-radius:50%;background:#f59e0b;animation:p 1.2s infinite}
        .callp.live .dot{background:#22c55e}
        .callp.done .dot{background:#6b7280;animation:none}
        @keyframes p{50%{opacity:.3}}
        .callp .hang{all:unset;cursor:pointer;width:44px;height:44px;border-radius:50%;background:#dc2626;display:grid;place-items:center;flex:none}
        .callp .hang:hover{background:#b91c1c}
        .callp .hang:disabled,.callp.done .hang{opacity:.4;cursor:default}
        .callp .hang svg{width:22px;height:22px;transform:rotate(135deg);fill:#fff}
      </style>
      <div class="tip"></div><button class="sheetbtn" type="button"></button><div class="toasts"></div>`;
    tip = sh.querySelector('.tip');
    {
      tip.style.cursor = 'pointer';
      tip.addEventListener('mouseenter', () => { tipHovered = true; clearTimeout(hideTimer); });
      tip.addEventListener('mouseleave', () => { tipHovered = false; setHover(null); });
      tip.addEventListener('click', (e) => {
        if (!e.isTrusted || !tipNumber) return;
        e.preventDefault(); e.stopPropagation();
        const n = tipNumber; tipHovered = false; setHover(null, true);
        call(n);
      });
    }
    sheetBtn = sh.querySelector('.sheetbtn');
    sheetBtn.addEventListener('click', (e) => {
      if (!e.isTrusted || !sheetNumber) return;
      e.preventDefault(); e.stopPropagation();
      call(sheetNumber);
    });
    toastBox = sh.querySelector('.toasts');
    document.documentElement.appendChild(ui);
  }

  function toast(res) {
    ensureUi();
    const el = document.createElement('div');
    el.className = 'toast ' + (res.ok ? 'ok' : (res.pending ? '' : 'err'));
    const span = document.createElement('span');
    span.textContent = (res.ok ? '📞 ' : '') + (res.text || '');
    el.appendChild(span);
    if (res.reason === 'no_tab') {
      const b = document.createElement('button');
      b.textContent = 'ulakBELL\'i aç';
      b.onclick = () => { chrome.runtime.sendMessage({ type: 'openUlakbell' }); el.remove(); };
      el.appendChild(b);
    }
    toastBox.appendChild(el);
    setTimeout(() => el.remove(), res.ok ? 3500 : 6000);
    return el;
  }

  async function call(number) {
    const waiting = toast({ pending: true, text: `${number} ulakBELL'e gönderiliyor…` });
    let res;
    try {
      res = await chrome.runtime.sendMessage({ type: 'call', number });
    } catch (e) {
      res = { ok: false, text: 'Eklenti yenilendi, sayfayı yeniden yükleyin.' };
    }
    waiting.remove();
    if (res && res.ok) showCallPanel({ number: res.number || number, state: 'Aranıyor…' });
    else toast(res || { ok: false, text: 'Arama başlatılamadı.' });
  }

  function ownButtonAt(x, y) {
    const list = [];
    if (tip && tip.style.display === 'block' && tip.style.pointerEvents === 'auto') list.push(tip);
    if (sheetBtn && sheetBtn.style.display === 'block') list.push(sheetBtn);
    const hb = panel && panel.isConnected && panel.querySelector('.hang');
    if (hb && !hb.disabled) list.push(hb);
    for (const el of list) {
      const r = el.getBoundingClientRect();
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return el;
    }
    return null;
  }
  async function hangupFromPanel(btn) {
    btn.disabled = true;
    panel.querySelector('.txt').textContent = 'Kapatılıyor…';
    try { await chrome.runtime.sendMessage({ type: 'hangup' }); } catch (_) {}
    poll();
  }

  // Görüşme paneli: durum, süre ve Kapat düğmesi
  let panel = null, pollTimer = null;
  const PHONE_SVG = '<svg viewBox="0 0 24 24"><path d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.02-.24c1.12.37 2.33.57 3.57.57a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C10.61 21 3 13.39 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1.02l-2.2 2.2z"/></svg>';

  function showCallPanel(st) {
    ensureUi();
    if (!panel || !panel.isConnected) {
      panel = document.createElement('div');
      panel.className = 'callp';
      panel.innerHTML = `<div class="info"><div class="num"></div><div class="st"><span class="dot"></span><span class="txt"></span></div></div>
        <button class="hang" title="Aramayı kapat">${PHONE_SVG}</button>`;
      panel.querySelector('.hang').addEventListener('click', (e) => {
        if (e.isTrusted && !e.currentTarget.disabled) hangupFromPanel(e.currentTarget);
      });
      toastBox.appendChild(panel);
    }
    panel.classList.remove('done');
    panel.classList.toggle('live', st.state === 'Görüşmede');
    panel.querySelector('.num').textContent = st.number || '';
    panel.querySelector('.txt').textContent = st.state + (st.duration ? ' · ' + st.duration : '');
    schedulePoll();
  }

  function endCallPanel() {
    clearTimeout(pollTimer);
    if (!panel || !panel.isConnected) return;
    panel.classList.add('done');
    panel.classList.remove('live');
    panel.querySelector('.txt').textContent = 'Görüşme bitti';
    panel.querySelector('.hang').disabled = true;
    const p = panel;
    setTimeout(() => { p.remove(); if (panel === p) panel = null; }, 2500);
  }

  function schedulePoll() {
    clearTimeout(pollTimer);
    if (document.visibilityState === 'visible') pollTimer = setTimeout(poll, 1000);
  }

  async function poll() {
    let st;
    try { st = await chrome.runtime.sendMessage({ type: 'status' }); } catch (_) { st = null; }
    if (st && st.active) showCallPanel(st);
    else if (panel) endCallPanel();
  }

  // Sayfa yenilenince ya da sekmeye dönülünce süren görüşmeyi yeniden göster
  // (iç çerçevelerde yalnız oradan başlatılan görüşme için panel açılır)
  if (IS_TOP) {
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') poll(); });
    poll();
  }

  // Fareyle üzerine gelince vurgula
  let hover = null, cursorEl = null, prevCursor = '';
  function setHover(hit, force) {
    if (BUTTON_MODE && !hit && !force) {
      // Fare numaradan düğmeye geçerken düğme kaybolmasın
      if (tipHovered || !hover) return;
      if (tip.style.pointerEvents !== 'auto') { setHover(null, true); return; }
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => { if (!tipHovered) setHover(null, true); }, 450);
      return;
    }
    clearTimeout(hideTimer);
    if (hover && hit && hover.item === hit.item && hover.node === hit.node) return;
    hover = hit;
    if (hlHover) { hlHover.clear(); if (hit) hlHover.add(hit.range); }
    if (cursorEl) { cursorEl.style.cursor = prevCursor; cursorEl = null; }
    if (hit) BUTTON_MODE = IS_ULAKBELL && isClickable(hit.node.parentElement);
    ensureUi();
    if (!hit) { tip.style.display = 'none'; tipNumber = null; return; }
    tipNumber = hit.item.number;
    if (!BUTTON_MODE) {
      cursorEl = hit.node.parentElement;
      if (cursorEl) { prevCursor = cursorEl.style.cursor; cursorEl.style.cursor = 'pointer'; }
    }
    tip.textContent = BUTTON_MODE ? '📞 Ara' : '📞 ulakBELL ile ara';
    tip.style.pointerEvents = BUTTON_MODE ? 'auto' : 'none';
    tip.style.cursor = BUTTON_MODE ? 'pointer' : 'default';
    tip.style.left = (hit.rect.left + hit.rect.width / 2) + 'px';
    tip.style.top = hit.rect.top + 'px';
    tip.style.display = 'block';
  }

  let rafPending = false, lastXY = null;
  document.addEventListener('mousemove', (e) => {
    if (!enabled || !byNode.size) return;
    lastXY = [e.clientX, e.clientY];
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(() => { rafPending = false; setHover(hitTest(lastXY[0], lastXY[1])); });
  }, { passive: true });
  window.addEventListener('scroll', () => hover && setHover(null), { passive: true, capture: true });

  // Tıklama: numara metni ya da tel: bağlantısı
  window.addEventListener('click', (e) => {
    // Yalnız kullanıcının gerçek tıklaması: sayfa kodunun ürettiği (el.click(), dispatchEvent) tıklamalar aramaz.
    if (!e.isTrusted || e.button !== 0) return;
    // Eklentinin kendi düğmeleri: tıklamayı yolda durduran sitelerde de çalışsın diye burada (en dışta) karşılanır
    const own = ownButtonAt(e.clientX, e.clientY);
    if (own) {
      e.preventDefault(); e.stopImmediatePropagation();
      if (own === tip) { const n = tipNumber; tipHovered = false; setHover(null, true); if (n) call(n); }
      else if (own === sheetBtn) { if (sheetNumber) call(sheetNumber); }
      else hangupFromPanel(own);
      return;
    }
    if (e.defaultPrevented) return;
    const link = e.target.closest && e.target.closest('a[href^="tel:" i]');
    if (link) {
      e.preventDefault(); e.stopPropagation();
      call(decodeURIComponent(link.getAttribute('href').replace(/^tel:/i, '')));
      return;
    }
    if (!enabled) return;
    const sel = window.getSelection();
    if (sel && !sel.isCollapsed && String(sel).trim().length > 0) return; // kopyalamak için seçiyorsa arama
    const hit = hitTest(e.clientX, e.clientY);
    if (!hit) return;
    // ulakBELL'de tıklanabilir öğedeki numara kendi işini yapsın; arama üstteki "Ara" düğmesiyle
    if (IS_ULAKBELL) {
      const same = hover && hover.node === hit.node && hover.item === hit.item;
      if (same ? BUTTON_MODE : (!cursorEl && isClickable(hit.node.parentElement))) return;
    }
    e.preventDefault(); e.stopPropagation();
    call(hit.item.number);
  }, true);

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    // Kısayol: seçili metin, Sheets'te etkin hücre ya da imlecin altındaki numara
    if (msg && msg.type === 'pick') {
      const sel = String(window.getSelection() || '').trim();
      sendResponse(sel || sheetNumber || (hover && hover.item.number) || '');
      return;
    }
    if (msg && msg.type === 'toast') {
      if (msg.res && msg.res.ok) showCallPanel({ number: msg.res.number, state: 'Aranıyor…' });
      else toast(msg.res);
    }
  });

  // Ayarlar
  chrome.storage.sync.get({ highlight: true }).then(({ highlight }) => {
    enabled = highlight;
    if (hasHighlight) {
      injectStyle();
      CSS.highlights.set('ulakbell-tel', hl);
      CSS.highlights.set('ulakbell-tel-hover', hlHover);
    }
    scan();
    new MutationObserver((muts) => {
      if (muts.some(m => {
        const t = m.target.nodeType === 1 ? m.target : m.target.parentElement;
        if (!t || (ui && ui.contains(t))) return false;
        return !(IS_ULAKBELL && t.closest && t.closest('.HuxTeleweb'));
      })) scheduleScan();
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  });
  // Google E-Tablolar: hücreler tuval (canvas) üzerine çizildiği için metin sayfada yoktur.
  // Seçili hücrenin içeriği formül çubuğunda görünür; numara varsa hücrenin yanında "Ara" düğmesi çıkar.
  if (IS_SHEETS) {
    const sheetCheck = () => {
      if (document.visibilityState !== 'visible') return;
      const fb = document.querySelector('#t-formula-bar-input .cell-input');
      const txt = fb ? fb.innerText.trim() : '';
      let num = null;
      if (txt && txt.length < 200) {
        if (/^[\d\s()+.\-]{7,20}$/.test(txt)) num = validNumber(txt, true);
        if (!num) { RE.lastIndex = 0; let m; while (!num && (m = RE.exec(txt))) num = validNumber(m[0]); }
      }
      ensureUi();
      const borders = [...document.querySelectorAll('.active-cell-border')].map(e => e.getBoundingClientRect()).filter(r => r.width || r.height);
      if (!num || !borders.length) { sheetNumber = null; sheetBtn.style.display = 'none'; return; }
      const right = Math.max(...borders.map(r => r.right)), top = Math.min(...borders.map(r => r.top));
      const bottom = Math.max(...borders.map(r => r.bottom));
      sheetNumber = num;
      sheetBtn.textContent = '📞 ' + num + ' ara';
      sheetBtn.style.left = Math.min(right + 6, innerWidth - 170) + 'px';
      sheetBtn.style.top = (top + (bottom - top) / 2 - 13) + 'px';
      sheetBtn.style.display = 'block';
    };
    setInterval(sheetCheck, 300);
  }

  chrome.storage.onChanged.addListener((ch) => {
    if (ch.highlight) { enabled = ch.highlight.newValue; setHover(null); scan(); }
  });
})();
