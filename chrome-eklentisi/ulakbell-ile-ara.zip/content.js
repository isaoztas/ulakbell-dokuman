// ulakBELL ile Ara — sayfa betiği
// Sayfadaki telefon numaralarını sayfanın DOM'una dokunmadan (CSS Highlight API) işaretler,
// tıklanınca numarayı arka plana gönderir; tel: bağlantılarını da ulakBELL'e yönlendirir.
(() => {
  if (window.__ulakbellAra) return;
  window.__ulakbellAra = true;

  // +90 532 123 45 67 · 0 (532) 123 45 67 · 0532-123-4567 · 0212 123 45 67 · 0850 ... · 444 1 234 · 444 12 34
  const RE = /(?<![\d+])(?:(?:\+|00)\s?90[\s.\-]?|90[\s.\-]|0[\s.\-]?)?(?:\([2-58]\d{2}\)|\(0[2-58]\d{2}\)|[2-58]\d{2})[\s.\-]?\d{3}[\s.\-]?\d{2}[\s.\-]?\d{2}(?![\d])|(?<![\d])444[\s.\-]?(?:\d[\s.\-]?\d{3}|\d{2}[\s.\-]?\d{2})(?![\d])/g;
  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'SVG', 'CANVAS', 'IFRAME', 'TEMPLATE']);
  const MAX_MATCHES = 3000;

  let enabled = true;
  let byNode = new Map();   // Text -> [{start, end, number}]
  const hasHighlight = typeof CSS !== 'undefined' && CSS.highlights && typeof Highlight === 'function';
  const hl = hasHighlight ? new Highlight() : null;
  const hlHover = hasHighlight ? new Highlight() : null;

  function validNumber(m) {
    const d = m.replace(/\D/g, '');
    if (/^444\d{4}$/.test(d)) return d;
    let n = d;
    if (n.startsWith('0090')) n = n.slice(4);
    else if (n.startsWith('90') && n.length === 12) n = n.slice(2);
    else if (n.startsWith('0')) n = n.slice(1);
    if (!/^([2-5]\d{9}|8(00|50)\d{7})$/.test(n)) return null;
    // Ayraçsız ve ön eksiz 10 haneli sayılar (sipariş no vb.) numara sayılmasın
    if (/^\d{10}$/.test(m)) return null;
    return '0' + n;
  }

  function injectStyle() {
    if (document.getElementById('ulakbell-ara-style')) return;
    const st = document.createElement('style');
    st.id = 'ulakbell-ara-style';
    st.textContent = `
      ::highlight(ulakbell-tel){ text-decoration: underline dotted #16a34a 2px; text-underline-offset: 3px; }
      ::highlight(ulakbell-tel-hover){ background-color: rgba(22,163,74,.18); text-decoration: underline solid #16a34a 2px; text-underline-offset: 3px; }`;
    (document.head || document.documentElement).appendChild(st);
  }

  function scan() {
    byNode = new Map();
    if (hl) hl.clear();
    if (!enabled || !document.body) return;
    let count = 0;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const v = node.nodeValue;
        if (!v || v.length < 7 || !/\d{3}/.test(v)) return NodeFilter.FILTER_REJECT;
        for (let el = node.parentElement; el && el !== document.body; el = el.parentElement) {
          if (SKIP.has(el.tagName.toUpperCase()) || el.isContentEditable || el.id === 'ulakbell-ara-ui') return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    let node;
    while ((node = walker.nextNode()) && count < MAX_MATCHES) {
      const text = node.nodeValue;
      RE.lastIndex = 0;
      let m;
      while ((m = RE.exec(text))) {
        const number = validNumber(m[0]);
        if (!number) continue;
        const item = { start: m.index, end: m.index + m[0].length, number };
        if (!byNode.has(node)) byNode.set(node, []);
        byNode.get(node).push(item);
        if (hl) {
          const r = document.createRange();
          r.setStart(node, item.start); r.setEnd(node, item.end);
          hl.add(r);
        }
        count++;
      }
    }
  }

  let scanTimer = null;
  function scheduleScan() {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(scan, 400);
  }

  // İmlecin altındaki numarayı bul
  function hitTest(x, y) {
    const pos = document.caretPositionFromPoint
      ? document.caretPositionFromPoint(x, y)
      : (document.caretRangeFromPoint && document.caretRangeFromPoint(x, y));
    if (!pos) return null;
    const node = pos.offsetNode || pos.startContainer;
    const offset = pos.offset != null ? pos.offset : pos.startOffset;
    const items = byNode.get(node);
    if (!items) return null;
    for (const it of items) {
      if (offset < it.start || offset > it.end) continue;
      const r = document.createRange();
      r.setStart(node, it.start); r.setEnd(node, it.end);
      for (const rect of r.getClientRects()) {
        if (x >= rect.left - 2 && x <= rect.right + 2 && y >= rect.top - 2 && y <= rect.bottom + 2) {
          return { node, item: it, range: r, rect };
        }
      }
    }
    return null;
  }

  // Küçük arayüz (ipucu + bildirim), sayfa stillerinden etkilenmesin diye shadow DOM içinde
  let ui, tip, toastBox;
  function ensureUi() {
    if (ui && ui.isConnected) return;
    ui = document.createElement('div');
    ui.id = 'ulakbell-ara-ui';
    ui.style.cssText = 'all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483647';
    const sh = ui.attachShadow({ mode: 'closed' });
    sh.innerHTML = `
      <style>
        .tip{position:fixed;display:none;transform:translate(-50%,-100%);margin-top:-6px;background:#16a34a;color:#fff;
             font:600 12px/1 system-ui,-apple-system,"Segoe UI",sans-serif;padding:6px 9px;border-radius:999px;white-space:nowrap;
             box-shadow:0 2px 8px rgba(0,0,0,.25)}
        .toasts{position:fixed;right:16px;bottom:16px;display:flex;flex-direction:column;gap:8px;align-items:flex-end}
        .toast{pointer-events:auto;background:#1f2937;color:#fff;font:14px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;
               padding:10px 14px;border-radius:10px;box-shadow:0 4px 16px rgba(0,0,0,.3);max-width:340px;display:flex;gap:10px;align-items:center}
        .toast.ok{background:#15803d}
        .toast.err{background:#b91c1c}
        .toast button{all:unset;cursor:pointer;background:rgba(255,255,255,.2);padding:4px 10px;border-radius:6px;font-weight:600;white-space:nowrap}
        .callp{pointer-events:auto;background:#111827;color:#fff;font:14px/1.3 system-ui,-apple-system,"Segoe UI",sans-serif;
               padding:12px 12px 12px 16px;border-radius:14px;box-shadow:0 6px 24px rgba(0,0,0,.35);display:flex;gap:14px;align-items:center;min-width:250px}
        .callp .info{flex:1;display:flex;flex-direction:column;gap:2px}
        .callp .num{font-weight:700;font-size:15px;letter-spacing:.3px}
        .callp .st{font-size:12px;color:#9ca3af;display:flex;gap:6px;align-items:center}
        .callp .dot{width:8px;height:8px;border-radius:50%;background:#f59e0b;animation:p 1.2s infinite}
        .callp.live .dot{background:#22c55e}
        .callp.done .dot{background:#6b7280;animation:none}
        @keyframes p{50%{opacity:.3}}
        .callp .hang{all:unset;cursor:pointer;width:44px;height:44px;border-radius:50%;background:#dc2626;display:grid;place-items:center;flex:none}
        .callp .hang:hover{background:#b91c1c}
        .callp .hang:disabled,.callp.done .hang{opacity:.4;cursor:default}
        .callp .hang svg{width:22px;height:22px;transform:rotate(135deg);fill:#fff}
      </style>
      <div class="tip"></div><div class="toasts"></div>`;
    tip = sh.querySelector('.tip');
    toastBox = sh.querySelector('.toasts');
    document.documentElement.appendChild(ui);
  }

  function toast(res) {
    ensureUi();
    const el = document.createElement('div');
    el.className = 'toast ' + (res.ok ? 'ok' : (res.pending ? '' : 'err'));
    const span = document.createElement('span');
    span.textContent = (res.ok ? '📞 ' : '') + (res.text || '');
    el.appendChild(span);
    if (res.reason === 'no_tab') {
      const b = document.createElement('button');
      b.textContent = 'ulakBELL\'i aç';
      b.onclick = () => { chrome.runtime.sendMessage({ type: 'openUlakbell' }); el.remove(); };
      el.appendChild(b);
    }
    toastBox.appendChild(el);
    setTimeout(() => el.remove(), res.ok ? 3500 : 6000);
    return el;
  }

  async function call(number) {
    const waiting = toast({ pending: true, text: `${number} ulakBELL'e gönderiliyor…` });
    let res;
    try {
      res = await chrome.runtime.sendMessage({ type: 'call', number });
    } catch (e) {
      res = { ok: false, text: 'Eklenti yenilendi, sayfayı yeniden yükleyin.' };
    }
    waiting.remove();
    if (res && res.ok) showCallPanel({ number: res.number || number, state: 'Aranıyor…' });
    else toast(res || { ok: false, text: 'Arama başlatılamadı.' });
  }

  // Görüşme paneli: durum, süre ve Kapat düğmesi
  let panel = null, pollTimer = null;
  const PHONE_SVG = '<svg viewBox="0 0 24 24"><path d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.02-.24c1.12.37 2.33.57 3.57.57a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1C10.61 21 3 13.39 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1.02l-2.2 2.2z"/></svg>';

  function showCallPanel(st) {
    ensureUi();
    if (!panel || !panel.isConnected) {
      panel = document.createElement('div');
      panel.className = 'callp';
      panel.innerHTML = `<div class="info"><div class="num"></div><div class="st"><span class="dot"></span><span class="txt"></span></div></div>
        <button class="hang" title="Aramayı kapat">${PHONE_SVG}</button>`;
      panel.querySelector('.hang').addEventListener('click', async (e) => {
        if (!e.isTrusted) return;
        e.currentTarget.disabled = true;
        panel.querySelector('.txt').textContent = 'Kapatılıyor…';
        try { await chrome.runtime.sendMessage({ type: 'hangup' }); } catch (_) {}
        poll();
      });
      toastBox.appendChild(panel);
    }
    panel.classList.remove('done');
    panel.classList.toggle('live', st.state === 'Görüşmede');
    panel.querySelector('.num').textContent = st.number || '';
    panel.querySelector('.txt').textContent = st.state + (st.duration ? ' · ' + st.duration : '');
    schedulePoll();
  }

  function endCallPanel() {
    clearTimeout(pollTimer);
    if (!panel || !panel.isConnected) return;
    panel.classList.add('done');
    panel.classList.remove('live');
    panel.querySelector('.txt').textContent = 'Görüşme bitti';
    panel.querySelector('.hang').disabled = true;
    const p = panel;
    setTimeout(() => { p.remove(); if (panel === p) panel = null; }, 2500);
  }

  function schedulePoll() {
    clearTimeout(pollTimer);
    if (document.visibilityState === 'visible') pollTimer = setTimeout(poll, 1000);
  }

  async function poll() {
    let st;
    try { st = await chrome.runtime.sendMessage({ type: 'status' }); } catch (_) { st = null; }
    if (st && st.active) showCallPanel(st);
    else if (panel) endCallPanel();
  }

  // Sayfa yenilenince ya da sekmeye dönülünce süren görüşmeyi yeniden göster
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') poll(); });
  poll();

  // Fareyle üzerine gelince vurgula
  let hover = null, cursorEl = null, prevCursor = '';
  function setHover(hit) {
    if (hover && hit && hover.item === hit.item && hover.node === hit.node) return;
    hover = hit;
    if (hlHover) { hlHover.clear(); if (hit) hlHover.add(hit.range); }
    if (cursorEl) { cursorEl.style.cursor = prevCursor; cursorEl = null; }
    ensureUi();
    if (!hit) { tip.style.display = 'none'; return; }
    cursorEl = hit.node.parentElement;
    if (cursorEl) { prevCursor = cursorEl.style.cursor; cursorEl.style.cursor = 'pointer'; }
    tip.textContent = `📞 ulakBELL ile ara`;
    tip.style.left = (hit.rect.left + hit.rect.width / 2) + 'px';
    tip.style.top = hit.rect.top + 'px';
    tip.style.display = 'block';
  }

  let rafPending = false, lastXY = null;
  document.addEventListener('mousemove', (e) => {
    if (!enabled || !byNode.size) return;
    lastXY = [e.clientX, e.clientY];
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(() => { rafPending = false; setHover(hitTest(lastXY[0], lastXY[1])); });
  }, { passive: true });
  window.addEventListener('scroll', () => hover && setHover(null), { passive: true, capture: true });

  // Tıklama: numara metni ya da tel: bağlantısı
  document.addEventListener('click', (e) => {
    // Yalnız kullanıcının gerçek tıklaması: sayfa kodunun ürettiği (el.click(), dispatchEvent) tıklamalar aramaz.
    if (!e.isTrusted || e.button !== 0 || e.defaultPrevented) return;
    const link = e.target.closest && e.target.closest('a[href^="tel:" i]');
    if (link) {
      e.preventDefault(); e.stopPropagation();
      call(decodeURIComponent(link.getAttribute('href').replace(/^tel:/i, '')));
      return;
    }
    if (!enabled) return;
    const sel = window.getSelection();
    if (sel && !sel.isCollapsed && String(sel).trim().length > 0) return; // kopyalamak için seçiyorsa arama
    const hit = hitTest(e.clientX, e.clientY);
    if (!hit) return;
    e.preventDefault(); e.stopPropagation();
    call(hit.item.number);
  }, true);

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === 'toast') {
      if (msg.res && msg.res.ok) showCallPanel({ number: msg.res.number, state: 'Aranıyor…' });
      else toast(msg.res);
    }
  });

  // Ayarlar
  chrome.storage.sync.get({ highlight: true }).then(({ highlight }) => {
    enabled = highlight;
    if (hasHighlight) {
      injectStyle();
      CSS.highlights.set('ulakbell-tel', hl);
      CSS.highlights.set('ulakbell-tel-hover', hlHover);
    }
    scan();
    new MutationObserver((muts) => {
      if (muts.some(m => !(ui && ui.contains(m.target)))) scheduleScan();
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  });
  chrome.storage.onChanged.addListener((ch) => {
    if (ch.highlight) { enabled = ch.highlight.newValue; setHover(null); scan(); }
  });
})();
