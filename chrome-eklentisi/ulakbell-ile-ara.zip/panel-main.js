// ulakBELL ile Ara — yan panel köprüsü (ulakBELL sayfasında, sayfanın kendi dünyasında çalışır).
// Yalnız bu eklentinin yan panelinin içindeki ulakBELL çerçevesinde devreye girer; normal sekmelerde hiçbir şey yapmaz.
(() => {
  const anc = location.ancestorOrigins;
  if (window.top === window || !anc || anc.length !== 1 || !/^chrome-extension:\/\//.test(anc[0])) return;
  const PARENT = anc[0];
  // Üst sayfa gerçekten bizim eklentimiz mi? (kimliği panel-id.js yazar)
  const ours = () => document.documentElement.getAttribute('data-ub-ext') === PARENT;

  // Çerçevede tarayıcı bildirimi açılamaz: teleweb'in bildirimlerini yan panele (eklenti bildirimine) aktar,
  // "bildirim izni gerekli" engeline takılmasın.
  function PanelNotification(title, opts) {
    if (ours()) try { parent.postMessage({ ubPanel: 'notify', title: String(title || ''), body: String((opts && opts.body) || '') }, PARENT); } catch (_) {}
    this.title = title; this.onclick = null; this.onclose = null;
  }
  PanelNotification.prototype.close = function () {};
  PanelNotification.prototype.addEventListener = function () {};
  Object.defineProperty(PanelNotification, 'permission', { get: () => 'granted' });
  PanelNotification.requestPermission = (cb) => { if (typeof cb === 'function') cb('granted'); return Promise.resolve('granted'); };
  try { window.Notification = PanelNotification; } catch (_) {}

  const tw = () => {
    const w = document.getElementById('wrapper');
    const root = w && w.__vue__;
    return root && root.$refs && root.$refs.teleweb;
  };

  const root = () => { const w = document.getElementById('wrapper'); return w && w.__vue__; };

  // Durum (mola) seçenekleri: yeni sürümde hesaplanmış liste, eskide gizli <select>
  // raw: ulakBELL'in kendi değeri (mola kimlikleri sayıdır); panele yazı olarak gider, geri gelince raw atanır.
  function statusOptions(c) {
    try {
      if (Array.isArray(c.telewebBreakOptions) && c.telewebBreakOptions.length) {
        return c.telewebBreakOptions.map(o => ({ value: String(o.value), raw: o.value, label: String(o.label || o.name || o.value), disabled: !!o.disabled }));
      }
    } catch (_) {}
    const sel = document.querySelector('#molamenu select:not([disabled])');
    if (!sel) return [];
    return [...sel.options].map(o => ({ value: String('_value' in o ? o._value : o.value), raw: '_value' in o ? o._value : o.value, label: o.textContent.trim(), disabled: o.disabled }));
  }
  // Durum değiştirilebilir mi? Yeni sürümde isTelewebStatusSelectDisabled, eski sürümde isVisibleStatusChanger (anlamı tersine) var.
  function canChangeStatus(c) {
    const r = root();
    const perms = (r && r.common && r.common.user_teleweb_permissions) || [];
    if (perms.indexOf && perms.indexOf('disable_queue') > -1) return false;
    if (c.teleweb_status_is_changing) return false;
    if ('isTelewebStatusSelectDisabled' in c) return !c.isTelewebStatusSelectDisabled;
    if ('isVisibleStatusChanger' in c) return !!c.isVisibleStatusChanger;
    return true;
  }
  // Kullanıcının bakması gereken bir pencere (Burada Kullan, mola onayı, sonuç kodu…) açık mı?
  function needsAttention(c) {
    if (c.open_call_disposition_modal || c.is_opened_activity_complete_modal) return true;
    if (document.querySelector('.modal.in, .modal.show')) return true;
    return !!document.querySelector('.snotifyToast .snotifyToast__buttons button, .snotifyToast input, .snotifyToast textarea, .ulakbell-notify-root button');
  }

  // Bekleyen pencere varken telefonu gizle, pencere öne çıksın
  function attn(c) {
    const a = needsAttention(c);
    document.documentElement.classList.toggle('ub-attn', a);
    return a;
  }

  const actions = {
    call(number) {
      const c = tw();
      if (!c || typeof c.doCall !== 'function') return { ok: false, reason: 'no_teleweb' };
      const t = c.teleweb || {};
      if (t.isBroken || !t.registered) return { ok: false, reason: 'not_registered' };
      if (t.started) return { ok: false, reason: 'busy' };
      c.doCall(number);
      return t.started ? { ok: true } : { ok: false, reason: 'not_started' };
    },
    status() {
      const c = tw();
      const t = (c && c.teleweb) || {};
      if (!c) return { active: false, ready: false, present: false };
      const r = root();
      const base = {
        present: true,
        ready: !!t.registered && !t.isBroken,
        ext: (r && r.common && r.common.loggedInUser && r.common.loggedInUser.teleweb_extension) || t.extension || '',
        queue: t.queue_status === undefined || t.queue_status === null ? '' : String(t.queue_status),
        options: statusOptions(c).map(({ value, label, disabled }) => ({ value, label, disabled })),
        canChange: canChangeStatus(c),
        attention: attn(c),
        waiting: c.is_show_waiting_count ? (c.number_of_calls || 0) : null,
        breakTime: t.molaSuresi || ''
      };
      const phase = t.alttakim || '';
      if (!t.started && phase !== 'ararken') return { ...base, active: false, phase: 'idle' };
      let state = 'Aranıyor…';
      if (phase === 'acinca') state = 'Görüşmede';
      else if (phase === 'ararken') state = 'Gelen çağrı';
      else if (/çal/i.test(t.telHeader || '')) state = 'Çalıyor…';
      return { ...base, active: true, phase, state,
        duration: t.aramasuresi || '', number: t.arayanNumara || '', name: t.arayanDisplayname || t.kuyruk_ismi || '',
        muted: t.mutedurum === 0, held: t.holddurum === 0 };
    },
    hangup() {
      const c = tw();
      const t = (c && c.teleweb) || {};
      if (!c) return { ok: false };
      if (t.alttakim === 'ararken') { c.reddet(); return { ok: true }; }
      if (!t.started) return { ok: true };
      c.doHangup(false, t.alttakim === 'acinca' ? 'log_5' : 'log_4');
      return { ok: true };
    },
    answer() { const c = tw(); if (c && c.teleweb && c.teleweb.alttakim === 'ararken') { c.cevapver(); return { ok: true }; } return { ok: false }; },
    mute() { const c = tw(); if (c && c.teleweb && c.teleweb.alttakim === 'acinca') { c.muteu(c); return { ok: true }; } return { ok: false }; },
    hold() { const c = tw(); if (c && c.teleweb && c.teleweb.alttakim === 'acinca') { c.holdu(); return { ok: true }; } return { ok: false }; },
    dtmf(tone) {
      const c = tw(); tone = String(tone || '');
      if (!c || !/^[0-9*#]$/.test(tone)) return { ok: false };
      c.tusbas(tone); return { ok: true };
    },
    setStatus(value) {
      const c = tw(); if (!c || !c.teleweb) return { ok: false };
      if (!canChangeStatus(c)) return { ok: false, reason: 'locked' };
      const opt = statusOptions(c).find(o => o.value === String(value) && !o.disabled);
      if (!opt) return { ok: false };
      c.teleweb.queue_status = opt.raw;   // ulakBELL'in kendi izleyicisi sunucuya bildirir (mola sınırı vb. kurallar orada)
      return { ok: true };
    }
  };

  window.addEventListener('message', (e) => {
    if (e.source !== window.parent || e.origin !== PARENT || !ours() || !e.data || e.data.ubPanel !== 'req') return;
    const { id, action, number } = e.data;
    let result;
    try { result = actions[action] ? actions[action](number) : { ok: false, reason: 'error' }; }
    catch (err) { result = { ok: false, reason: 'error', message: String(err && err.message || err) }; }
    parent.postMessage({ ubPanel: 'res', id, result }, PARENT);
  });

  // Görünüm: sayfanın geri kalanını gizle, teleweb'i panel genişliğine büyüt
  const css = `
    html.ub-panel, html.ub-panel body { overflow: hidden !important; background: #fff !important; }
    html.ub-panel body { visibility: hidden !important; }
    html.ub-panel #teleWrapper, html.ub-panel #teleWrapper *,
    html.ub-panel .snotify, html.ub-panel .snotify *,
    html.ub-panel .ulakbell-notify-root, html.ub-panel .ulakbell-notify-root *,
    html.ub-panel .modal.in, html.ub-panel .modal.in *, html.ub-panel .modal.show, html.ub-panel .modal.show * { visibility: visible !important; }
    html.ub-panel #teleWrapper { left: 0 !important; right: auto !important; top: 0 !important; bottom: auto !important; }
    html.ub-panel #teleWrapper.teleweb-topbar-mode-hidden { display: block !important; }
    html.ub-panel #surukle { display: none !important; }   /* sürükleme tutamacı panelde anlamsız */
    html.ub-panel .snotify { zoom: 0.9; }
    html.ub-panel.ub-attn #teleWrapper, html.ub-panel.ub-attn #teleWrapper * { visibility: hidden !important; }
    html.ub-panel.ub-attn .snotify, html.ub-panel.ub-attn .ulakbell-notify-root { z-index: 2147483000 !important; }`;
  // Yan panele "bu çerçevede ulakBELL hazır" sinyali: panel ancak bundan sonra soru gönderir
  // (yükleme ve sayfa geçişi sırasında çerçevede başka kökenli boş sayfa olabilir).
  function hello(state) { if (ours()) try { parent.postMessage({ ubPanel: state }, PARENT); } catch (_) {} }
  window.addEventListener('pagehide', () => hello('bye'));

  function apply() {
    hello('hello');
    if (!ours()) return;
    const w = document.getElementById('teleWrapper');
    if (!w) return;   // giriş sayfası ya da yükleniyor: sayfayı olduğu gibi göster
    if (!document.getElementById('ub-panel-style')) {
      const st = document.createElement('style');
      st.id = 'ub-panel-style'; st.textContent = css;
      (document.head || document.documentElement).appendChild(st);
    }
    document.documentElement.classList.add('ub-panel');
    // Gerçek (büyütülmemiş) boyutu ölç; panele hem enine hem boyuna sığacak kadar büyüt.
    // Tuş takımı açılıp kapanınca yükseklik değişir, her turda yeniden hesaplanır.
    const prev = w.style.zoom;
    w.style.zoom = '1';
    const r = w.getBoundingClientRect();
    const bw = Math.max(r.width, w.scrollWidth, 190);
    const bh = Math.max(r.height, w.scrollHeight, 80);
    const z = Math.max(1, Math.min(2.4, (window.innerWidth - 6) / bw, (window.innerHeight - 4) / bh));
    w.style.zoom = String(Math.round(z * 100) / 100);
    if (prev && Math.abs(parseFloat(prev) - z) < 0.02) w.style.zoom = prev;
  }
  const timer = setInterval(apply, 700);
  window.addEventListener('resize', apply);
  window.addEventListener('beforeunload', () => clearInterval(timer));
})();
