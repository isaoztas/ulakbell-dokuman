// ulakBELL ile Ara — arka plan
// Numarayı açık ulakBELL sekmesindeki teleweb'e ($root.$refs.teleweb.doCall) iletir.

const DEFAULTS = { host: 'emsal.ulakbel.com', focusTab: false, highlight: true };

async function getSettings() {
  return { ...DEFAULTS, ...(await chrome.storage.sync.get(DEFAULTS)) };
}

// Teleweb'in kendi normalizePhone'u da çalışır; burada yalnız rakamları sadeleştiriyoruz.
function cleanNumber(raw) {
  let n = String(raw || '').replace(/[^\d*#+]/g, '');
  if (n.startsWith('+')) n = n.slice(1);
  if (/^0090\d{10}$/.test(n)) n = '0' + n.slice(4);
  else if (/^90\d{10}$/.test(n)) n = '0' + n.slice(2);
  else if (/^[2-58]\d{9}$/.test(n)) n = '0' + n;
  return n;
}

// ulakBELL sayfasında (MAIN world) çalışır.
function callInPage(number) {
  try {
    const root = document.getElementById('wrapper') && document.getElementById('wrapper').__vue__;
    const tw = root && root.$refs && root.$refs.teleweb;
    if (!tw || typeof tw.doCall !== 'function') return { ok: false, reason: 'no_teleweb' };
    const t = tw.teleweb || {};
    if (t.isBroken || !t.registered) return { ok: false, reason: 'not_registered' };
    if (t.started) return { ok: false, reason: 'busy' };
    tw.doCall(number);
    return t.started ? { ok: true } : { ok: false, reason: 'not_started' };
  } catch (e) {
    return { ok: false, reason: 'error', message: String(e && e.message || e) };
  }
}

// ulakBELL sayfasında: görüşmenin durumu
function statusInPage() {
  try {
    const root = document.getElementById('wrapper') && document.getElementById('wrapper').__vue__;
    const tw = root && root.$refs && root.$refs.teleweb;
    if (!tw) return { active: false };
    const t = tw.teleweb || {};
    if (!t.started) return { active: false };
    let state = 'Aranıyor…';
    if (t.alttakim === 'acinca') state = 'Görüşmede';
    else if (/çal/i.test(t.telHeader || '')) state = 'Çalıyor…';
    return { active: true, state, duration: t.aramasuresi || '', number: t.arayanNumara || '' };
  } catch (e) {
    return { active: false };
  }
}

// ulakBELL sayfasında: teleweb'in kırmızı kapat düğmesiyle aynı işlem
function hangupInPage() {
  try {
    const root = document.getElementById('wrapper') && document.getElementById('wrapper').__vue__;
    const tw = root && root.$refs && root.$refs.teleweb;
    if (!tw) return { ok: false };
    const t = tw.teleweb || {};
    if (!t.started) return { ok: true };
    if (t.alttakim === 'acinca') tw.doHangup(false, 'log_5');
    else tw.doHangup(false, 'log_4');
    return { ok: true };
  } catch (e) {
    return { ok: false, message: String(e && e.message || e) };
  }
}

async function runIn(tabId, func) {
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func });
    return res && res.result;
  } catch (e) {
    return null;
  }
}

// Eklentinin başlattığı görüşme (servis çalışanı uykuya geçse de kaybolmasın)
async function getActive() {
  return (await chrome.storage.session.get('activeCall')).activeCall || null;
}

async function callStatus() {
  const active = await getActive();
  if (!active) return { active: false };
  const st = await runIn(active.tabId, statusInPage);
  if (!st || !st.active) {
    await chrome.storage.session.remove('activeCall');
    return { active: false, ended: true };
  }
  return { ...st, number: active.number };
}

async function hangup() {
  const active = await getActive();
  if (!active) return { ok: true };
  const res = await runIn(active.tabId, hangupInPage);
  return res || { ok: false };
}

const REASONS = {
  no_tab: 'Açık ulakBELL sekmesi yok. Önce ulakBELL\'e giriş yapın.',
  no_teleweb: 'ulakBELL sekmesinde teleweb bulunamadı (teleweb yetkisi kapalı olabilir).',
  not_registered: 'Teleweb santrale bağlı değil. ulakBELL sekmesini kontrol edin.',
  busy: 'Teleweb şu an başka bir görüşmede.',
  not_started: 'Teleweb aramayı başlatmadı.',
  bad_number: 'Geçerli bir Türkiye numarası değil (yurt dışı ve 0900 numaraları sayfalardan aranmaz).',
  error: 'Arama başlatılamadı.'
};

// Web sayfasından gelen numaralar yalnız Türkiye sabit/cep, 0800, 0850 ve 444 olabilir.
// Böylece bir site yurt dışı ya da 0900 gibi ücretli numaraları aratamaz.
function strictNumber(raw) {
  const d = String(raw || '').replace(/\D/g, '');
  if (/^444\d{4}$/.test(d)) return d;
  let n = d;
  if (n.startsWith('0090')) n = n.slice(4);
  else if (n.startsWith('90') && n.length === 12) n = n.slice(2);
  else if (n.startsWith('0')) n = n.slice(1);
  return /^([2-5]\d{9}|8(00|50)\d{7})$/.test(n) ? '0' + n : null;
}

// strict: numara bir web sayfasından ya da sağ tık menüsünden geldi.
// Yalnız eklenti penceresinde (popup) kullanıcının elle yazdığı numara serbesttir.
async function placeCall(raw, strict = true) {
  const number = strict ? strictNumber(raw) : cleanNumber(raw);
  if (!number || number.replace(/\D/g, '').length < 3) return { ok: false, reason: 'bad_number', text: REASONS.bad_number };

  const { host, focusTab } = await getSettings();
  const tabs = await chrome.tabs.query({ url: `https://${host}/*` });
  if (!tabs.length) return { ok: false, reason: 'no_tab', text: REASONS.no_tab, host, number };

  // Önce son kullanılan sekmeyi dene; teleweb bağlı olan ilk sekmede ara.
  tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  let last = { ok: false, reason: 'no_teleweb' };
  for (const tab of tabs) {
    try {
      const [res] = await chrome.scripting.executeScript({
        target: { tabId: tab.id }, world: 'MAIN', func: callInPage, args: [number]
      });
      last = (res && res.result) || last;
    } catch (e) {
      last = { ok: false, reason: 'error', message: String(e.message || e) };
    }
    if (last.ok) {
      await chrome.storage.session.set({ activeCall: { tabId: tab.id, number, at: Date.now() } });
      if (focusTab) {
        await chrome.tabs.update(tab.id, { active: true });
        await chrome.windows.update(tab.windowId, { focused: true });
      }
      return { ok: true, number, text: `${number} aranıyor…` };
    }
    if (last.reason === 'busy') break;
  }
  return { ...last, number, host, text: REASONS[last.reason] || REASONS.error };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'call') {
    // Sekmeden (içerik betiği) gelen istek katı kurala uyar; popup'ta sender.tab yoktur.
    const fromPopup = !sender.tab && sender.url && sender.url.startsWith(chrome.runtime.getURL('popup.html'));
    placeCall(msg.number, !fromPopup).then(sendResponse);
    return true;
  }
  if (msg && msg.type === 'status') {
    callStatus().then(sendResponse);
    return true;
  }
  if (msg && msg.type === 'hangup') {
    hangup().then(sendResponse);
    return true;
  }
  if (msg && msg.type === 'openUlakbell') {
    getSettings().then(({ host }) => chrome.tabs.create({ url: `https://${host}/` }));
  }
});

// Seçili metni sağ tıkla ara
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'ulakbell-ara', title: 'ulakBELL ile ara: "%s"', contexts: ['selection'] });
  chrome.contextMenus.create({ id: 'ulakbell-ara-link', title: 'ulakBELL ile ara', contexts: ['link'], targetUrlPatterns: ['tel:*'] });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const raw = info.menuItemId === 'ulakbell-ara-link'
    ? decodeURIComponent((info.linkUrl || '').replace(/^tel:/i, ''))
    : info.selectionText;
  const res = await placeCall(raw);
  if (tab && tab.id >= 0) chrome.tabs.sendMessage(tab.id, { type: 'toast', res }).catch(() => {});
});
