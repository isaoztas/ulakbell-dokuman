// ulakBELL ile Ara — arka plan
// Numarayı açık ulakBELL sekmesindeki teleweb'e ($root.$refs.teleweb.doCall) iletir.

const DEFAULTS = { host: 'emsal.ulakbel.com', focusTab: false, highlight: true };

async function getSettings() {
  return { ...DEFAULTS, ...(await chrome.storage.sync.get(DEFAULTS)) };
}

// Teleweb'in kendi normalizePhone'u da çalışır; burada yalnız rakamları sadeleştiriyoruz.
function cleanNumber(raw) {
  let n = String(raw || '').replace(/[^\d*#+]/g, '');
  if (n.startsWith('+')) n = n.slice(1);
  if (/^0090\d{10}$/.test(n)) n = '0' + n.slice(4);
  else if (/^90\d{10}$/.test(n)) n = '0' + n.slice(2);
  else if (/^[2-58]\d{9}$/.test(n)) n = '0' + n;
  return n;
}

// ulakBELL sayfasında (MAIN world) çalışır.
function callInPage(number) {
  try {
    const root = document.getElementById('wrapper') && document.getElementById('wrapper').__vue__;
    const tw = root && root.$refs && root.$refs.teleweb;
    if (!tw || typeof tw.doCall !== 'function') return { ok: false, reason: 'no_teleweb' };
    const t = tw.teleweb || {};
    if (t.isBroken || !t.registered) return { ok: false, reason: 'not_registered' };
    if (t.started) return { ok: false, reason: 'busy' };
    tw.doCall(number);
    return t.started ? { ok: true } : { ok: false, reason: 'not_started' };
  } catch (e) {
    return { ok: false, reason: 'error', message: String(e && e.message || e) };
  }
}

// ulakBELL sayfasında: görüşmenin durumu
function statusInPage() {
  try {
    const root = document.getElementById('wrapper') && document.getElementById('wrapper').__vue__;
    const tw = root && root.$refs && root.$refs.teleweb;
    if (!tw) return { active: false };
    const t = tw.teleweb || {};
    if (!t.started) return { active: false };
    let state = 'Aranıyor…';
    if (t.alttakim === 'acinca') state = 'Görüşmede';
    else if (/çal/i.test(t.telHeader || '')) state = 'Çalıyor…';
    return { active: true, state, duration: t.aramasuresi || '', number: t.arayanNumara || '' };
  } catch (e) {
    return { active: false };
  }
}

// ulakBELL sayfasında: teleweb'in kırmızı kapat düğmesiyle aynı işlem
function hangupInPage() {
  try {
    const root = document.getElementById('wrapper') && document.getElementById('wrapper').__vue__;
    const tw = root && root.$refs && root.$refs.teleweb;
    if (!tw) return { ok: false };
    const t = tw.teleweb || {};
    if (!t.started) return { ok: true };
    if (t.alttakim === 'acinca') tw.doHangup(false, 'log_5');
    else tw.doHangup(false, 'log_4');
    return { ok: true };
  } catch (e) {
    return { ok: false, message: String(e && e.message || e) };
  }
}

// ulakBELL sekmesinde: telefon boştaysa bırak (sunucu bir dahiliyi tek yerde bağlar; yan panel alabilsin)
function releaseInPage() {
  try {
    const root = document.getElementById('wrapper') && document.getElementById('wrapper').__vue__;
    const tw = root && root.$refs && root.$refs.teleweb;
    if (!tw) return { ok: true, none: true };
    const t = tw.teleweb || {};
    if (t.started || t.alttakim === 'ararken') return { ok: false, reason: 'in_call' };
    if (!t.registered || typeof tw.telewebDestroy !== 'function') return { ok: true, none: true };
    try { if (typeof tw.save_teleweb_refresh_request === 'function') tw.save_teleweb_refresh_request(); } catch (_) {}
    tw.telewebDestroy();
    return { ok: true, released: true };
  } catch (e) {
    return { ok: false, reason: 'error', message: String(e && e.message || e) };
  }
}

// Yan panelin "Telefonu buraya al" düğmesi: sekmelerdeki telefonu bırakır
async function releaseTabs() {
  const { host } = await getSettings();
  const tabs = await chrome.tabs.query({ url: `https://${host}/*` });
  let released = 0;
  for (const tab of tabs) {
    const r = await runIn(tab.id, releaseInPage);
    if (r && r.reason === 'in_call') return { ok: false, reason: 'in_call' };
    if (r && r.released) released++;
  }
  return { ok: true, released };
}

// ---- Yan panel telefonu ----
// Yan panel (sidepanel.html) açıksa istek ona gider; kapalıysa null döner.
async function panelAsk(action, number) {
  try {
    const r = await chrome.runtime.sendMessage({ target: 'sidepanel', action, number });
    return r || null;
  } catch (_) {
    return null;
  }
}

// Yan paneldeki ulakBELL çerçevesi "başka sitede çerçevelenemez" başlıkları yüzünden açılmaz.
// Bu kural yalnız sekme dışı (tabId -1: eklentinin yan paneli) çerçeve isteklerinde o başlıkları kaldırır;
// normal sekmelerdeki ulakBELL sayfalarına ve başka sitelere dokunmaz.
async function ensurePanelRule() {
  const { host } = await getSettings();
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [1],
    addRules: [{
      id: 1, priority: 1,
      action: { type: 'modifyHeaders', responseHeaders: [
        { header: 'x-frame-options', operation: 'remove' },
        { header: 'content-security-policy', operation: 'remove' }
      ] },
      // Yalnız bu eklentinin kendi sayfasının (yan panel) açtığı çerçeve: başka eklentilerin sayfaları hariç
      condition: { requestDomains: [host], resourceTypes: ['sub_frame'], tabIds: [chrome.tabs.TAB_ID_NONE], initiatorDomains: [chrome.runtime.id] }
    }]
  });
}
chrome.runtime.onStartup.addListener(() => ensurePanelRule().catch(() => {}));
chrome.runtime.onInstalled.addListener(() => ensurePanelRule().catch(() => {}));
chrome.storage.onChanged.addListener((ch) => { if (ch.host) ensurePanelRule().catch(() => {}); });

async function runIn(tabId, func) {
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func });
    return res && res.result;
  } catch (e) {
    return null;
  }
}

// Eklentinin başlattığı görüşme (servis çalışanı uykuya geçse de kaybolmasın)
async function getActive() {
  return (await chrome.storage.session.get('activeCall')).activeCall || null;
}

async function callStatus() {
  const active = await getActive();
  if (!active) return { active: false };
  const st = active.panel ? await panelAsk('status') : await runIn(active.tabId, statusInPage);
  if (!st || !st.active) {
    await chrome.storage.session.remove('activeCall');
    return { active: false, ended: true };
  }
  return { ...st, number: active.number };
}

async function hangup() {
  const active = await getActive();
  if (!active) return { ok: true };
  const res = active.panel ? await panelAsk('hangup') : await runIn(active.tabId, hangupInPage);
  return res || { ok: false };
}

const REASONS = {
  no_tab: 'Açık ulakBELL sekmesi yok. Önce ulakBELL\'e giriş yapın.',
  no_teleweb: 'ulakBELL sekmesinde teleweb bulunamadı (teleweb yetkisi kapalı olabilir).',
  not_registered: 'Teleweb santrale bağlı değil. ulakBELL sekmesini kontrol edin.',
  busy: 'Teleweb şu an başka bir görüşmede.',
  not_started: 'Teleweb aramayı başlatmadı.',
  bad_number: 'Geçerli bir Türkiye numarası değil (yurt dışı ve 0900 numaraları sayfalardan aranmaz).',
  error: 'Arama başlatılamadı.'
};

// Web sayfasından gelen numaralar yalnız Türkiye sabit/cep, 0800, 0850 ve 444 olabilir.
// Böylece bir site yurt dışı ya da 0900 gibi ücretli numaraları aratamaz.
const NUM_RE = /(?<![\d+])(?:(?:\+|00)\s?90[\s.\-]?|90[\s.\-]|0[\s.\-]?)?(?:\(0?[2-58]\d{2}\)|[2-58]\d{2})[\s.\-]?\d{3}[\s.\-]?\d{2}[\s.\-]?\d{2}(?!\d)|(?<!\d)444[\s.\-]?(?:\d[\s.\-]?\d{3}|\d{2}[\s.\-]?\d{2})(?!\d)/g;
function strictNumber(raw) {
  raw = String(raw || '').trim();
  const whole = strictDigits(raw);
  if (whole) return whole;
  // "Tel: 0532 123 45 67 (Ahmet Bey)" gibi metinlerin içinden ilk geçerli numarayı al
  if (raw.length > 500) raw = raw.slice(0, 500);
  NUM_RE.lastIndex = 0;
  let m;
  while ((m = NUM_RE.exec(raw))) { const n = strictDigits(m[0]); if (n) return n; }
  return null;
}
function strictDigits(raw) {
  if (!/^[\d\s()+.\-\/]{7,24}$/.test(raw)) return null;
  const d = raw.replace(/\D/g, '');
  if (/^444\d{4}$/.test(d)) return d;
  let n = d;
  if (n.startsWith('0090')) n = n.slice(4);
  else if (n.startsWith('90') && n.length === 12) n = n.slice(2);
  else if (n.startsWith('0')) n = n.slice(1);
  return /^([2-5]\d{9}|8(00|50)\d{7})$/.test(n) ? '0' + n : null;
}

// strict: numara bir web sayfasından ya da sağ tık menüsünden geldi.
// Yalnız eklenti penceresinde (popup) kullanıcının elle yazdığı numara serbesttir.
async function placeCall(raw, strict = true) {
  const number = strict ? strictNumber(raw) : cleanNumber(raw);
  if (!number || number.replace(/\D/g, '').length < 3) return { ok: false, reason: 'bad_number', text: REASONS.bad_number };

  const { host, focusTab } = await getSettings();

  // Yan panel açıksa telefon oradadır: önce orayı dene
  const pr = await panelAsk('call', number);
  if (pr && pr.ok) {
    await chrome.storage.session.set({ activeCall: { panel: true, number, at: Date.now() } });
    return { ok: true, number, text: `${number} aranıyor…` };
  }
  if (pr && pr.reason === 'busy') return { ...pr, number, host, text: REASONS.busy };

  const tabs = await chrome.tabs.query({ url: `https://${host}/*` });
  if (!tabs.length) {
    if (pr) return { ...pr, number, host, text: REASONS[pr.reason] || REASONS.error };
    return { ok: false, reason: 'no_tab', text: REASONS.no_tab, host, number };
  }

  // Önce son kullanılan sekmeyi dene; teleweb bağlı olan ilk sekmede ara.
  tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  let last = { ok: false, reason: 'no_teleweb' };
  for (const tab of tabs) {
    try {
      const [res] = await chrome.scripting.executeScript({
        target: { tabId: tab.id }, world: 'MAIN', func: callInPage, args: [number]
      });
      last = (res && res.result) || last;
    } catch (e) {
      last = { ok: false, reason: 'error', message: String(e.message || e) };
    }
    if (last.ok) {
      await chrome.storage.session.set({ activeCall: { tabId: tab.id, number, at: Date.now() } });
      if (focusTab) {
        await chrome.tabs.update(tab.id, { active: true });
        await chrome.windows.update(tab.windowId, { focused: true });
      }
      return { ok: true, number, text: `${number} aranıyor…` };
    }
    if (last.reason === 'busy') break;
  }
  return { ...last, number, host, text: REASONS[last.reason] || REASONS.error };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'call') {
    // Sekmeden (içerik betiği) gelen istek katı kurala uyar; popup'ta sender.tab yoktur.
    const fromPopup = !sender.tab && sender.url && sender.url.startsWith(chrome.runtime.getURL('popup.html'));
    placeCall(msg.number, !fromPopup).then(sendResponse);
    return true;
  }
  if (msg && msg.type === 'status') {
    callStatus().then(sendResponse);
    return true;
  }
  if (msg && msg.type === 'hangup') {
    hangup().then(sendResponse);
    return true;
  }
  if (msg && msg.type === 'readClipboard') return; // offscreen belgesinin işi
  if (msg && msg.target === 'sidepanel') return;   // yan panelin işi
  if (msg && msg.type === 'releaseTabs') {
    releaseTabs().then(sendResponse);
    return true;
  }
  if (msg && msg.type === 'ensurePanelRule') {
    ensurePanelRule().then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, text: String(e) }));
    return true;
  }
  if (msg && msg.type === 'openPanel') {
    // popup'tan gelir (kullanıcı tıklaması); pencere kimliği popup tarafından verilir
    chrome.sidePanel.open({ windowId: msg.windowId }).then(() => sendResponse({ ok: true }), (e) => sendResponse({ ok: false, text: String(e) }));
    return true;
  }
  if (msg && msg.type === 'openUlakbell') {
    getSettings().then(({ host }) => chrome.tabs.create({ url: `https://${host}/` }));
  }
});

// Seçili metni sağ tıkla ara
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'ulakbell-ara', title: 'ulakBELL ile ara: "%s"', contexts: ['selection'] });
  chrome.contextMenus.create({ id: 'ulakbell-ara-link', title: 'ulakBELL ile ara', contexts: ['link'], targetUrlPatterns: ['tel:*'] });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const raw = info.menuItemId === 'ulakbell-ara-link'
    ? decodeURIComponent((info.linkUrl || '').replace(/^tel:/i, ''))
    : info.selectionText;
  const res = await placeCall(raw);
  if (tab && tab.id >= 0) chrome.tabs.sendMessage(tab.id, { type: 'toast', res }).catch(() => {});
});


// ---- Kısayollar: her programdan arama ve kapatma ----
// "ara": Chrome öndeyse sayfadaki seçili metin / Sheets hücresi / imlecin altındaki numara;
// başka bir programdaysanız (Excel, Outlook, WhatsApp…) son kopyaladığınız metindeki numara aranır.
async function readClipboard() {
  try {
    if (!(await chrome.offscreen.hasDocument())) {
      await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['CLIPBOARD'], justification: 'Kısayola basıldığında kopyalanan telefon numarasını okumak' });
    }
    const text = await chrome.runtime.sendMessage({ type: 'readClipboard', target: 'offscreen' });
    return String(text || '');
  } catch (_) {
    return '';
  } finally {
    chrome.offscreen.closeDocument().catch(() => {});
  }
}

function notify(title, message) {
  chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title, message, priority: 1 }).catch(() => {});
}

async function focusedTab() {
  const win = await chrome.windows.getLastFocused().catch(() => null);
  if (!win || !win.focused) return null;
  const [tab] = await chrome.tabs.query({ active: true, windowId: win.id });
  return tab || null;
}

chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd === 'ara') {
    const tab = await focusedTab();
    let text = '', from = 'clipboard';
    if (tab) {
      try { text = await chrome.tabs.sendMessage(tab.id, { type: 'pick' }); } catch (_) {}
      if (text) from = 'page';
    }
    if (!text) text = await readClipboard();
    if (!text.trim()) {
      notify('ulakBELL ile Ara', 'Numarayı seçin ya da kopyalayın (⌘C / Ctrl+C), sonra kısayola yeniden basın.');
      return;
    }
    const res = await placeCall(text, true);
    if (res.reason === 'bad_number') res.text = from === 'clipboard'
      ? 'Kopyaladığınız metinde aranacak bir Türkiye numarası bulunamadı.'
      : res.text;
    let shown = false;
    if (tab) {
      try { await chrome.tabs.sendMessage(tab.id, { type: 'toast', res }); shown = true; } catch (_) {}
    }
    if (!shown) notify(res.ok ? 'ulakBELL arıyor' : 'ulakBELL ile Ara', res.ok ? res.number : res.text);
  }
  if (cmd === 'kapat') {
    const st = await callStatus();
    if (!st || !st.active) { notify('ulakBELL ile Ara', 'Süren bir görüşme yok.'); return; }
    await hangup();
    const tab = await focusedTab();
    if (!tab) notify('ulakBELL ile Ara', `${st.number} görüşmesi kapatıldı.`);
  }
});
